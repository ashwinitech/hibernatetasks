package com.xyz.Hibernatedb.DAOModel;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
	@Table(name="UserModel")
	public class UserModel
	{
	 @Id	
	  private int UserId;
	  private String UserName;
	  private String UserAddress;
	  private String UserEmail;
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserAddress() {
		return UserAddress;
	}
	public void setUserAddress(String userAddress) {
		UserAddress = userAddress;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	} 
	}


