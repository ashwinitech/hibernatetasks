package com.xyz.Hibernatedb.DAOImpl;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xyz.Hibernatedb.DbConfig;
import com.xyz.Hibernatedb.DAO.CategoryDAO;
import com.xyz.Hibernatedb.DAOModel.CategoryModel;

public class CategoryDAOImpl implements CategoryDAO
{
		private Transaction trans;
		private Session sess;
		private boolean b=true;
		
		public void addCategory(CategoryModel c) {
			try
			{
				DbConfig db=new DbConfig();
				sess=db.getSess();
				trans=sess.beginTransaction();
				sess.save(c);
				trans.commit();
			}
			catch(Exception t)
			{
				System.out.println(t);
			}
			
}

}



