package com.xyz.Hibernatedb;


import com.xyz.Hibernatedb.DAOImpl.CategoryDAOImpl;
import com.xyz.Hibernatedb.DAOImpl.ProductDAOImpl;
import com.xyz.Hibernatedb.DAOImpl.UserDAOImpl;
import com.xyz.Hibernatedb.DAOModel.ProductModel;
import com.xyz.Hibernatedb.DAOModel.CategoryModel;
import com.xyz.Hibernatedb.DAOModel.UserModel;

public class AppConfig {


	public static void main(String[] args) {
	ProductModel p=new ProductModel();
	p.setPid(1);
	p.setPname("Abi");
	p.setPprice(100);
	
	CategoryModel c=new CategoryModel();
	c.setCid(101);
	c.setCname("achu");
	
	UserModel u=new UserModel();
	u.setUserId(1001);
	u.setUserName("Ashwini");
	u.setUserEmail("ashwinianand3712gmail.com");
	u.setUserAddress("617/3,Sirumani Nagar,Balakrishnapuram,Dindigul-624005");
	
	ProductDAOImpl pm=new ProductDAOImpl();
	CategoryDAOImpl cm=new CategoryDAOImpl(); 
	UserDAOImpl um=new UserDAOImpl(); 
	pm.addProduct(p);
	cm.addCategory(c);
	um.addUser(u);
	System.out.println("InsertedSucess");

}

}

