package com.xyz.Hibernatedb.DAOModel;
	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Entity
		@Table(name="CategoryModel")
		public class CategoryModel
		{
		 @Id	
		  private int Cid;
		  private String Cname;
		public int getCid() {
			return Cid;
		}
		public void setCid(int Cid) {
			this.Cid = Cid;
		}
		public String getCname() {
			return Cname;
		}
		public void setCname(String Cname) {
			this.Cname = Cname;
		}
		  
		}

