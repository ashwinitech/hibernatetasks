package com.xyz.Hibernatedb.DAO;

import com.xyz.Hibernatedb.DAOModel.CategoryModel;

public interface CategoryDAO {
	public void addCategory(CategoryModel c);
	}

