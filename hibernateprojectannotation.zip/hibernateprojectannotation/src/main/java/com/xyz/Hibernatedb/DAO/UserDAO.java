package com.xyz.Hibernatedb.DAO;

import com.xyz.Hibernatedb.DAOModel.UserModel;

public interface UserDAO {
	public void addUser(UserModel u);
	}
