package com.xyz.Hibernatedb.DAOImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xyz.Hibernatedb.DbConfig;
import com.xyz.Hibernatedb.DAO.ProductDAO;
import com.xyz.Hibernatedb.DAOModel.ProductModel;

public class ProductDAOImpl implements ProductDAO
{
		private Transaction trans;
		private Session sess;
		private boolean b=true;

		public void addProduct(ProductModel p) {
			try
			{
				DbConfig db=new DbConfig();
				sess=db.getSess();
				trans=sess.beginTransaction();
				sess.save(p);
				trans.commit();
			}
			catch(Exception t)
			{
				System.out.println(t);
			}
			
}
}