package com.xyz.Hibernatedb.DAO;

import com.xyz.Hibernatedb.DAOModel.ProductModel;

public interface ProductDAO {

	public void addProduct(ProductModel p);
}
