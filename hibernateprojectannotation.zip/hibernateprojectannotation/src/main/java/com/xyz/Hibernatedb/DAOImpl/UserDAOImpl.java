package com.xyz.Hibernatedb.DAOImpl;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.xyz.Hibernatedb.DbConfig;
import com.xyz.Hibernatedb.DAO.UserDAO;
import com.xyz.Hibernatedb.DAOModel.UserModel;

public class UserDAOImpl implements UserDAO{
	private Transaction trans;
	private Session sess;
	private boolean b=true;

	public void addUser(UserModel u) {
		try
		{
			DbConfig db=new DbConfig();
			sess=db.getSess();
			trans=sess.beginTransaction();
			sess.save(u);
			trans.commit();
		}
		catch(Exception t)
		{
			System.out.println(t);
		}
		

	}

		
}
